#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
    
    /* CONFIGURATION VARIABLES */
    frameCapacity = 30;
    effectDelay = 10;
    effectDuration = 10;
    
    screenWidth = ofGetScreenWidth();
    screenHeight = ofGetScreenHeight();
    windowWidth = ofGetWindowWidth();
    windowHeight = ofGetWindowHeight();
    
    slits.allowExt("jpg");
	slits.allowExt("png");
    slits.allowExt("gif");
	slits.listDir("slits");
	currentSlit = 0;
    totalSlits = slits.size();
    cout << "totalSlits: " << totalSlits;
    slitScan.setup(windowWidth,windowHeight,frameCapacity,OF_IMAGE_COLOR);
    //slitScan.setup(screenWidth,screenHeight,frameCapacity,OF_IMAGE_COLOR);
	if(totalSlits !=0){
		loadSlit(slits.getPath(currentSlit));
	}
    
    //blending means the edges between the scans are feathered
    slitScan.setBlending(true);
    //time delay is the deepest in history the delay can go
    //and width is the number of frames the distortion will encompass
    //note that the delay cannot be more than the total capacity
    slitScan.setTimeDelayAndWidth(effectDelay, effectDuration);
    
    //set up the grabber
    //grabber.initGrabber(1280, 960);
    //grabber.initGrabber(screenWidth, screenHeight);
    grabber.initGrabber(windowWidth, windowHeight);
    
    /* SYPHON SETUP */
	ofSetWindowTitle("Slitscan");
	mainOutputSyphonServer.setName("Slitscan");
    mClient.setup();
    mClient.setApplicationName("Simple Server");
    mClient.setServerName("");
    ofSetFrameRate(60); // caps the framerate at 60fps.
    
}

//--------------------------------------------------------------
void testApp::update(){
    grabber.update();
    if(grabber.isFrameNew()){
        slitScan.addImage(grabber);
    }
}

//--------------------------------------------------------------
void testApp::draw(){
    slitScan.getOutputImage().draw(0, 0);
    
    /* SYPHON */
    ofSetColor(255, 255, 255);
    ofEnableAlphaBlending();
    mClient.draw(50, 50);    
	mainOutputSyphonServer.publishScreen();
}

//--------------------------------------------------------------
void testApp::loadSlit(string slit){
    cout << "slit to load: " << slit;
	distortionMap.loadImage(slit);
    //distortionMap.resize(screenWidth, screenHeight); //mh resize distortion map to size of screen
    distortionMap.resize(windowWidth, windowHeight); //mh resize distortion map to size of window
    slitScan.setDelayMap(distortionMap);
}

//--------------------------------------------------------------
void testApp::keyPressed(int key){
    switch(key){
        case OF_KEY_UP: //cycle forward through slits
            if (currentSlit < totalSlits-1){
                currentSlit++;
            } else {
                currentSlit = 0;
            }
            loadSlit(slits.getPath(currentSlit));
            break;
        case OF_KEY_DOWN: //cycle back through slits
            if (currentSlit > 0){
                currentSlit--;
            } else {
                currentSlit = totalSlits-1;
            }
            loadSlit(slits.getPath(currentSlit));
            break;
        case OF_KEY_RIGHT: //increase delay
            if (effectDelay + effectDuration < frameCapacity){
                effectDelay++;
            } 
            slitScan.setTimeDelayAndWidth(effectDelay, effectDuration);
            break;
        case OF_KEY_LEFT: //decrease delay
            if (effectDelay > 0){
                effectDelay--;
            }
            slitScan.setTimeDelayAndWidth(effectDelay, effectDuration);
            break;
        case '[': //decrease duration
            if (effectDuration > 1){
                effectDuration--;
            }
            slitScan.setTimeDelayAndWidth(effectDelay, effectDuration);
            break;
        case ']': //increase duration
            if (effectDelay + effectDuration < frameCapacity){
                effectDuration++;
            } 
            slitScan.setTimeDelayAndWidth(effectDelay, effectDuration);
            break;
	}
}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){ 

}