#pragma once

#include "ofMain.h"
#include "ofxSlitScan.h"

#include "ofxSyphon.h"

class testApp : public ofBaseApp{
  public:
    void setup();
    void update();
    void draw();
    
    void keyPressed(int key);
    void windowResized(int w, int h);
    void dragEvent(ofDragInfo dragInfo);
    void gotMessage(ofMessage msg);

    ofxSlitScan slitScan;
    ofVideoGrabber grabber;
    
    /*CONFIGURATION VARIABLES */
    int windowWidth;
    int windowHeight;
    int screenWidth;
    int screenHeight;
    int frameCapacity;
    int effectDelay;
    int effectDuration;
    
    ofDirectory slits;
	int currentSlit;
    int totalSlits;
    void loadSlit(string slit);
    ofImage distortionMap;
    
    /* SYPHON */
	ofxSyphonServer mainOutputSyphonServer;
	ofxSyphonClient mClient;
    
    
};
